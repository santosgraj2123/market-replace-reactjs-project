import React from "react";
import Layout from "./../components/Layout/Layout";

const Offers = () => {
  return (
    <Layout>
      <h1>Offer page</h1>
    </Layout>
  );
};

export default Offers;
