import React from "react";
import Layout from "./../components/Layout/Layout";

const ForgotPassword = () => {
  return (
    <Layout>
      <h1>ForgotPassword page</h1>
    </Layout>
  );
};

export default ForgotPassword;
