import React from "react";

const Footer = () => {
  return (
    <div className="d-flex align-items-center justify-content-center bg-dark text-light p-4">
      <h6>All Right Reserved &copy; TECHINFOYT - 2022</h6>
    </div>
  );
};

export default Footer;
